//
//  AppDelegate.h
//  TestRC
//
//  Created by chengjian on 2019/7/30.
//  Copyright © 2019 chengjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

